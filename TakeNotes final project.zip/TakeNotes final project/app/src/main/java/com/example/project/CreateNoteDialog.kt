package com.example.project

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import androidx.compose.ui.platform.LocalContext


@Composable //Composable function to make a dialog for creating a new note
//declares lambda function that takes one parameter, onDismiss.
fun CreateNoteDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    //state holders for user input
    val title = remember { mutableStateOf("") }
    val content = remember { mutableStateOf("") }

    //Display a modal dialog when the onDismissRequest lambda is triggered
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .background(Color.White) //Makes the dialog background white
                .padding(16.dp), //adds padding inside the dialog
            horizontalAlignment = Alignment.CenterHorizontally //centers the content horizontally
        ) {
            Text("New Note", fontSize = 20.sp) //Displays the title of the dialog with sp used for scalable text size
            Spacer(Modifier.height(8.dp)) //adds vertical spacing between elements
            TextField( //text field input for the note's title, with the value bound ot the title state and updates stored with onValueChange
                value = title.value,
                onValueChange = { title.value = it },
                label = { Text("Title") }
            )
            Spacer(Modifier.height(8.dp)) //spacing between elements
            TextField( //another text field for the note's content again with the value bound to the content state and updates bound to onValueChange
                value = content.value,
                onValueChange = { content.value = it },
                label = { Text("Content") }
            )
            Spacer(Modifier.height(16.dp)) //spacer between elements
            Button(onClick = { //creates the save note button, click handler defines what happens when its pressed
                val userId = FirebaseAuth.getInstance().currentUser?.uid //retrieves ID of current user. if no user is logged in the uid will be null
                if (userId.isNullOrBlank() || title.value.isBlank() || content.value.isBlank()) { //if any fields are blank the missing data toast is made
                    Toast.makeText(context, "Missing data", Toast.LENGTH_SHORT).show()

                    return@Button //returns state to before button is clicked
                }

                val db = FirebaseFirestore.getInstance() //initiaizes firestore and prepares a new document reference in the notes collection
                val newDocRef = db.collection("notes").document() //generates a unique ID to store the note under
                val noteToSave = Note( //creates a Note object ot be saved including the generated ID, current input, and timestamp
                    id = newDocRef.id,
                    title = title.value,
                    content = content.value,
                    userId = userId,
                    timestamp = System.currentTimeMillis()
                )

                newDocRef //saves note in firestore, on success shows a toast message and closes the dialog
                    .set(noteToSave)
                    .addOnSuccessListener {
                        Toast.makeText(context, "Note created", Toast.LENGTH_SHORT).show()

                        onDismiss()
                    }
                    .addOnFailureListener { e -> //if the save ails an error message is shown using the exception message from firebase
                        Toast.makeText(context, "Create failed “${e.message}”", Toast.LENGTH_SHORT).show()

                    }
            }) { //Defines the cancel button which calls onDismiss to simply close the dialog without saving.
                Text("Save Note")
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    }
}
