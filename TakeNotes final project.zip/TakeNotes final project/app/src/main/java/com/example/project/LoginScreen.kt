package com.example.project//declares package this file belongs to

//all imports needed for UI elements, toast and firebase
import android.util.Patterns
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LoginScreen( //declares a composable function for rendering login UI taking 2 parameters, which trigger different functions.
    onLoginClick: (String, String) -> Unit, //what to do when the user logs in
    onRegisterClick: () -> Unit //what to do when the user taps the register link.
) {
    val context = LocalContext.current //needed to show Toast notifications
    var email by remember { mutableStateOf("") } //store user input with Compose state
    var password by remember { mutableStateOf("") }//store user input with Compose state

    val greenGradient = Brush.verticalGradient( //creates a soft green vertical gradaient background
        colors = listOf(
            Color(0xFFa8e6cf),
            Color(0xFFdcedc1),
            Color(0xFFaed581)
        )
    )

    Box( //fills the whole screen with the gradaient and cneters its child (Column)
        modifier = Modifier
            .fillMaxSize()
            .background(brush = greenGradient),
        contentAlignment = Alignment.Center
    ) {
        Column( //creates white translucent rounded background with padding for child elements
            modifier = Modifier
                .padding(24.dp)
                .background(Color.White.copy(alpha = 0.8f), shape = RoundedCornerShape(16.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally //centers child elements horizontally
        ) {
            Text( //outputs welcome back with a dark green colour
                text = "Welcome Back!",
                fontSize = 28.sp,
                color = Color(0xFF388e3c)
            )

            Spacer(modifier = Modifier.height(24.dp)) //leaves 24 dp space between elements

            OutlinedTextField( //text field allowing for user input labeled Email
                value = email,
                onValueChange = { email = it },
                label = { Text("Email") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp)) //space between elements of 16 dp

            OutlinedTextField( //input fields that hides entered characters controlled by the password state
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(24.dp)) //space of 24 dp

            Button( //below executes when button "login" is clicked
                onClick = {
                    val isEmailValid = Patterns.EMAIL_ADDRESS.matcher(email).matches() //validates email usign built in function
                    if (email.isBlank() || password.isBlank()) { //if inputs are empty shows a notificatoin
                        Toast.makeText(context, "Email and password cannot be empty", Toast.LENGTH_SHORT).show()
                    } else if (!isEmailValid) { //if email is not valid shows notification
                        Toast.makeText(context, "Invalid email format", Toast.LENGTH_SHORT).show()
                    } else { //else calls the onLoginClick function with the entered email and password
                        onLoginClick(email, password)
                    }
                },//denotes default button colours
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4caf50)),
                modifier = Modifier.fillMaxWidth() //fills the screen
            ) {
                Text("Login", color = Color.White) //titles login
            }

            Spacer(modifier = Modifier.height(12.dp)) //spacer between this and register option

            TextButton(onClick = { onRegisterClick() }) { //asks users to ergister to make account
                Text("Don't have an account? Register", color = Color(0xFF388e3c))
            }
        }
    }
}
