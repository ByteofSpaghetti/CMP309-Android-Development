package com.example.project
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable //renders registration form interface
fun RegisterScreen(
    onRegisterClick: (String, String) -> Unit, //invoked when a valid registratoin is submitted
    onLoginClick: () -> Unit //navigates to the login screen used in the TextButton
) {
    val context = LocalContext.current //grabs androids context inside compose needed for toast
    var emailError by remember { mutableStateOf<String?>(null) }//holds error of email field if its invalid
    var email by remember { mutableStateOf("") } //form input for all inputs used to hold all user input
    var password by remember { mutableStateOf("") } //holds user input
    var confirmPassword by remember { mutableStateOf("") } //holds user input

    val greenGradient = Brush.verticalGradient( //creates a soft green vertical gradient in the background
        colors = listOf(
            Color(0xFFa8e6cf),
            Color(0xFFdcedc1),
            Color(0xFFaed581)
        )
    )

    Box( //Frame layout for stackign children
        modifier = Modifier
            .fillMaxSize() //fills screen
            .background(brush = greenGradient), ///background set to gradient declared above
        contentAlignment = Alignment.Center //centers content
    ) {
        Column(//creates a white rounded card with padding for child elements
            modifier = Modifier
                .padding(24.dp) //padding
                .background(Color.White.copy(alpha = 0.8f), shape = RoundedCornerShape(16.dp)) //sets colour and form for register card
                .padding(24.dp), //padding
            horizontalAlignment = Alignment.CenterHorizontally //centers form elements horizontally
        ) {
            Text( //green button titled Create Account with a large font size
                text = "Create Account",
                fontSize = 28.sp,
                color = Color(0xFF388e3c)
            )

            Spacer(modifier = Modifier.height(24.dp)) //spacer of 24.dp

            OutlinedTextField(//provides output for email, filling max width, and usign onValueChange to hold given user input
                value = email,
                onValueChange = { email = it },
                label = { Text("Email") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp)) //spacer of 16.dp

            OutlinedTextField(//obscured password field labeled password filling width of given card and using onValueChange to hold user input
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp)) //spacer to

            OutlinedTextField(//obscured password field labeled password filling width of given card and using onValueChange to hold user input
                value = confirmPassword,
                onValueChange = { confirmPassword = it },
                label = { Text("Confirm Password") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            if (emailError != null) {//displays emailerror in red text below inputs with compose shwoing/hiding it conditionally
                Text(
                    text = emailError!!,//holds email error
                    color = Color.Red,//colour red
                    fontSize = 14.sp,//sets fontsize
                    modifier = Modifier//modifier for altering the looks
                        .fillMaxWidth()//fills max width
                        .padding(top = 4.dp)//padding for top of error to distance from confirm input
                )
            }


            Spacer(modifier = Modifier.height(24.dp)) //spacer

            Button( //onclick executes when button is clicked checking when all fields contain valid input
                onClick = {

                        val isEmailValid = android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() //uses preconstructed email validatoin function to check the email is valid

                        if (email.isBlank() || password.isBlank() || confirmPassword.isBlank()) { //if any fields are empty shows toast error
                            emailError = "Fields cannot be empty"
                            Toast.makeText(context, "Fields cannot be empty", Toast.LENGTH_SHORT).show()

                        } else if (!isEmailValid) { //if email does not match valid format shows error
                            emailError = "Invalid email format"
                            Toast.makeText(context, "Invalid email format", Toast.LENGTH_SHORT).show()

                        } else if (password != confirmPassword) { //if password does not equal confirm password shows toast error
                            emailError = null
                            Toast.makeText(context, "Passwords do not match", Toast.LENGTH_SHORT).show()
                        } else { //if all fields are valid registers user showing Registration Complete! toast message
                            emailError = null
                            onRegisterClick(email, password)
                            Toast.makeText(context, "Registration Complete!", Toast.LENGTH_SHORT).show()

                        }

                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4caf50)), //sets button colour
                modifier = Modifier.fillMaxWidth()//button fills max width
            ) {
                Text("Register", color = Color.White) //makes register text white
            }

            Spacer(modifier = Modifier.height(12.dp)) //spacer

            TextButton(onClick = { onLoginClick() }) { //creates button allowing to navigate back the the Login screen. 
                Text("Already have an account? Login", color = Color(0xFF388e3c))
            }
        }
    }
}

