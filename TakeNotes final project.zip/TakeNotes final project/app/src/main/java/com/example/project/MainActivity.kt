package com.example.project //declares package this file belongs to

//imports classes for android lifecycvle, Jetpack, Firebase and navigation.
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import com.example.project.ui.theme.ProjectTheme
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() { //decleares main activity of the app
    override fun onCreate(savedInstanceState: Bundle?) { //ensures parent lifecycle is maintained
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() //allows drawing under system bars
        FirebaseApp.initializeApp(this) // initialises firebase for the app

        setContent { //sets the UI content using Jetpack Compose
            ProjectTheme {//applies custom theme
                val navController = rememberNavController() //creates and remembers navigation controller for switching screens.
                var message by remember { mutableStateOf<String?>(null) }//declares message variable to show feedback messages
                val context = LocalContext.current
                NavHost(navController = navController, startDestination = "auth") { //sets up compose navigatoin, first screen is auth

                    composable("auth") {//defines auth screen composable and tracks wheter user is on the login or register view
                        var isLoginScreen by remember { mutableStateOf(true) }

                        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->//scaffold sets up screen layout
                            Column(//column vertically arranges elements with spacing
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                if (isLoginScreen) { //shows the login screen composable if isLoginScreen is true, else shows the register screen
                                    LoginScreen(
                                        onLoginClick = { email, password ->
                                            val auth = FirebaseAuth.getInstance()
                                            auth.signInWithEmailAndPassword(email, password)
                                                .addOnCompleteListener { task ->
                                                    if (task.isSuccessful) { //if login is successful, goes to dashboard!
                                                        navController.navigate("dashboard")
                                                    } else { //else shows error message
                                                        message = task.exception?.message ?: "Login failed"
                                                        Toast.makeText(context, message ?: "Login failed", Toast.LENGTH_SHORT).show()

                                                    }
                                                }
                                        },
                                        onRegisterClick = { isLoginScreen = false }
                                    )
                                } else {
                                    RegisterScreen(
                                        onRegisterClick = { email, password -> //creates new user using entered email and password
                                            val auth = FirebaseAuth.getInstance()
                                            auth.createUserWithEmailAndPassword(email, password)
                                                .addOnCompleteListener { task ->
                                                    if (task.isSuccessful) { //if succcessful shows success message
                                                        Toast.makeText(context, message ?: "Registration successful", Toast.LENGTH_SHORT).show()

                                                    } else { //if failed error message is shown
                                                        message = task.exception?.message ?: "Registration failed"
                                                        Toast.makeText(context, message ?:"Registration failed", Toast.LENGTH_SHORT).show()

                                                    }
                                                }
                                        },
                                        onLoginClick = { isLoginScreen = true } //should switch back to login screen
                                    )
                                }

                                // creates adn defines feedback messages
                                message?.let {
                                    Text(
                                        text = it,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        textAlign = TextAlign.Center
                                    )

                                    LaunchedEffect(message) { //displays message in centered text view auto clears message after 3 seconds
                                        delay(3000)
                                        message = null
                                    }
                                }
                            }
                        }
                    }

                    // Dashboard Composable to be shown after successsful login.
                    composable("dashboard") {
                        DashboardScreen()
                    }
                }
            }
        }
    }
}

