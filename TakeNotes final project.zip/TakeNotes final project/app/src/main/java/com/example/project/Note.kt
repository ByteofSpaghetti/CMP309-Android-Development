package com.example.project

data class Note( //kotlin data class used to represent one note in the app
    val title: String = "", //notes title initialised as an empty string
    val content: String = "", //main content of the note
    val userId: String = "",//userID used to contain a users UID
    val timestamp: Long = System.currentTimeMillis(), //creates a timestamp for the note
    val id: String = "" //string to hold a uniquely generated ID for the note
)