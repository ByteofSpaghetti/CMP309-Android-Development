package com.example.project

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun NoteList(
    notes: List<Note>,
    onEdit: (Note) -> Unit,
    onDelete: (Note) -> Unit,
    modifier: Modifier = Modifier
) {
    // keep track of scroll state
    val listState = rememberLazyListState()

    LazyColumn(
        state = listState,
        modifier = modifier
            .fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp),       // space between items
        horizontalAlignment = Alignment.CenterHorizontally,     // center items
        contentPadding = PaddingValues(vertical = 8.dp)
    ) {
        items(notes, key = { it.id }) { note ->
            NoteCardEdit(
                note     = note,
                onEdit   = onEdit,
                onDelete = onDelete
            )
        }
    }
}




@Composable
fun NoteCardEdit(
    note: Note,
    onEdit: (Note) -> Unit,
    onDelete: (Note) -> Unit
) {
    // allow us to show a Toast
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .padding(8.dp)
            .background(Color(0xFFE0F2F1))
            .padding(16.dp)
    ) {
        Text(text = note.title, fontSize = 18.sp, color = Color(0xFF00796B))
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = note.content, fontSize = 14.sp, color = Color.DarkGray)
        Spacer(modifier = Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onEdit(note) }) {
                Text("Edit")
            }
            Button(
                onClick = {
                    Toast.makeText(context, "Deleting “${note.title}”…", Toast.LENGTH_SHORT).show()
                    onDelete(note)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)) // <-- Added here
            ) {
                Text(
                    text = "Delete",
                    color = Color.White
                )
            }
        }
    }
}


