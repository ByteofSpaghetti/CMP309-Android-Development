package com.example.project

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

@Composable //main composable function renders the users dashboard including notes, create/edit dialog and Firebase sync
fun DashboardScreen() {
    val context = LocalContext.current//uses the Android Context needed to display toast messages

    val showCreateNote = remember { mutableStateOf(false) } //controls visibility of the Create Note dialog
    val editingNote = remember { mutableStateOf<Note?>(null) } //Stores note currently beign editied. Null means no edit dialog is open.
    var notes by remember { mutableStateOf<List<Note>>(emptyList()) }//Holds the list of notes fetched from Firestore, triggering recomposition when updated.
    val userId = FirebaseAuth.getInstance().currentUser?.uid //Retrieves current users UID used for quering notes


    var listenerRegistration: ListenerRegistration? by remember { mutableStateOf(null) } //Stores a Firestore real-time listener

    LaunchedEffect(userId) { //runs a one time fetch when composable is first composed or the userId changes
        if (userId != null) { //queries the notes collection for all documents where userId matches the logged-in user.
            FirebaseFirestore.getInstance()
                .collection("notes")
                .whereEqualTo("userId", userId)
                .get()
                .addOnSuccessListener { snapshot ->
                    val initialNotes = snapshot.documents.mapNotNull { doc -> //Converts Firestore documents to Note objectes inserting each documents ID manually since toObject() does not use it
                        doc.toObject(Note::class.java)?.copy(id = doc.id)
                    }
                    notes = initialNotes
                }
                .addOnFailureListener { e -> //shows a toast if the fetch fails
                    Toast.makeText(context, "Error getting notes “${e.message}”", Toast.LENGTH_SHORT).show()
                }
        }
    }

    DisposableEffect(userId) {//runs when userId changes and disposes when the composable leaves the UI tree
        if (userId != null) { //adds a real-time listener to Firestore for the suers notes whenever their is a change
            listenerRegistration = FirebaseFirestore.getInstance() //connects to Firestore and listens to the notes collection in real time filtered by current user
                .collection("notes")
                .whereEqualTo("userId", userId)
                .addSnapshotListener { snapshot, error -> //callback that fires whenever a note is added, edited or deleted, the query is invalid or the connection to Firestore changes
                    if (error != null) { //checks if FIrestore returned an error. If there is an error shows a toast to the user
                        Toast.makeText(context, "Error getting notes “${error.message}”", Toast.LENGTH_SHORT).show()
                        return@addSnapshotListener //exits early from the callback to avoid using a invalid snapshot
                    }

                    if (snapshot != null) { //if no errors in snapshot
                        val fetchedNotes = snapshot.documents.mapNotNull { doc -> //list of documents returned by Firestore and each docuemnt is converted into a Note object
                            doc.toObject(Note::class.java)?.copy(id = doc.id) //toObject
                        }
                        // Update the notes state with the new list
                        notes = fetchedNotes
                    }
                }
        }

        onDispose { //cleans up the listneer to avoid memory leaks or duplicate listener.
            listenerRegistration?.remove()
        }
    }

    Box( //outer container
        modifier = Modifier
            .fillMaxSize() //ensures entire screen is occupied
            .background(Color(0xFFe8f5e9)), // green tone
        contentAlignment = Alignment.Center //aligns content
    ) {
        Column( //arranges child eleemnts vertically
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp), //gives room from screen edges
            horizontalAlignment = Alignment.CenterHorizontally // ensures buttons andtext are centered horizontally
        ) {
            Text("TakeNotes", fontSize = 24.sp, color = Color(0xFF2e7d32)) //displays app name in a big green header
            Spacer(modifier = Modifier.height(16.dp))

            Button(onClick = { showCreateNote.value = true }) {//toggles showCreateNote to true controlling the visibility of the Create note dialog
                Text("Create New Note")
            } //triggers state change and a recomposition where the dialog is conditionally rendered

            Spacer(modifier = Modifier.height(24.dp)) //spacing
            Text("Your Notes", fontSize = 20.sp, color = Color(0xFF2e7d32))//outputs Your Notes in a big green header to idnicate the current users saved notes
            Spacer(modifier = Modifier.height(8.dp)) //spacer

            NoteList( //displays the lsit of notes
                notes   = notes,
                onEdit  = { editingNote.value = it }, //sets the selected note for editing which triggeres the Edit dialog
                onDelete = { note -> //directly deletes the note from firestore
                    FirebaseFirestore.getInstance()
                        .collection("notes")
                        .document(note.id)
                        .delete()
                        .addOnSuccessListener { //on success shows a success toast message
                            Toast.makeText(context, "Deleted “${note.title}”", Toast.LENGTH_SHORT).show()
                        }
                        .addOnFailureListener { e -> //on failure shows a failure toast message
                            Toast.makeText(context, "Delete failed: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                },
                modifier = Modifier
                    .fillMaxWidth() //ensures list stretches across the screen
                    .weight(1f) //lets it take up all available vertical space
            )


            editingNote.value?.let { note -> //shown only if a note is slected, dismassal sets editingNote to null
                EditNoteDialog(
                    note = note,
                    onDismiss = { editingNote.value = null }
                )
            }

            if (showCreateNote.value) { //shows the create note dialog is showCreateNote is true
                CreateNoteDialog(onDismiss = { showCreateNote.value = false })
            }
        }
    }
}
