package com.example.project

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.google.firebase.firestore.FirebaseFirestore

@Composable //composable modal dialog for editing an existing note
fun EditNoteDialog(note: Note, onDismiss: () -> Unit) { //takes the note to be editied and onDismiss as parameters
    val context = LocalContext.current //retrieves the android context to show toast messages
    //initializes state with the notes current title and content using remember to ensure changes are kept across recompositions
    val title = remember { mutableStateOf(note.title) }
    val content = remember { mutableStateOf(note.content) }

    Dialog(onDismissRequest = onDismiss) { //creates a modal overlay
        Column( //dialogs layout, vertical stack of input and buttons styled with apdding and white background
            modifier = Modifier //
                .background(Color.White) //sets background to white
                .padding(16.dp), //spacing
            horizontalAlignment = Alignment.CenterHorizontally //centers the content
        ) {
            Text("Edit Note", fontSize = 20.sp) //section heading for the dialog
            Spacer(modifier = Modifier.height(8.dp)) //spacing
            TextField(value = title.value, onValueChange = { title.value = it }, label = { Text("Title") }) //declares two input fields with spacing for user input
            Spacer(modifier = Modifier.height(8.dp)) //spacing
            TextField(value = content.value, onValueChange = { content.value = it }, label = { Text("Content") }) //user input for Content
            Spacer(modifier = Modifier.height(16.dp))//spacer
            Button(onClick = { //button
                val db = FirebaseFirestore.getInstance() //gets a firestore database instance
                val updates = mapOf( //constructs a map of the fields to updated. the update function takes a Map as an arugment
                    "title" to title.value,
                    "content" to content.value,
                    "timestamp" to System.currentTimeMillis()
                )

                db.collection("notes") //navigates to the exact document in the notes colection using the notes id
                    .document(note.id)
                    .update(updates) //calls update to modify only the specified fields preserving others like userid
                    .addOnSuccessListener {
                        println("Note updated!")
                        Toast.makeText(context, "note updated “${note.title}”…", Toast.LENGTH_SHORT).show() //if this succeeds shows a success toast

                        onDismiss() //dismisses the dialog using the onDismiss lambda function passed in by the caller
                    }
                    .addOnFailureListener { e -> //shows a toast message on failure to update the note
                        Toast.makeText(context, "note failed to updated “${e.message}”…", Toast.LENGTH_SHORT).show()

                    }
            }) {//button title
                Text("Save Changes")
            }

            Spacer(modifier = Modifier.height(8.dp))//spacer
            Button(onClick = onDismiss) {//button to cancel the edit
                Text("Cancel")
            }
        }
    }
}



